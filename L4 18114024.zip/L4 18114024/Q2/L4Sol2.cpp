/**
 * @file L4Sol2.cpp
 * @author G.Satya Vamsi
 * @brief To generate all possible solutions of N-Queen problem
 * @date 2019-09-03
 * 
 */
#include<bits/stdc++.h>
#define N 100

using namespace std;

void print(int x,int matrix[N][N]){ 
	static int k = 1; 
	cout<<k<<endl;
	k++; 
	for (int i = 0; i < x; i++) { 
		for (int j = 0; j < x; j++) 
			cout<<matrix[i][j]<<" "; 
		cout<<endl; 
	} 
	cout<<endl; 
} 

/**
 * @brief Checks whether the position is safe
 * @param matrix 
 * @param x 
 * @param row 
 * @param col 
 * @return bool
 */
bool isitok(int x,int matrix[N][N], int row, int col) { 
	int i, j; 

	for (i=0; i<col; i++) 
		if (matrix[row][i]) 
			return false; 

	for (i=row, j=col; i>=0 && j>=0; i--, j--) 
		if (matrix[i][j]) 
			return false; 

	for (i=row, j=col; j>=0 && i<x; i++, j--) 
		if (matrix[i][j]) 
			return false; 

	return true; 
} 

/**
 * @brief Checks for a particular value of column
 * @param matrix 
 * @param x
 * @return bool
 */
bool subsolveit(int x,int matrix[N][N], int col) { 
	if (col == x) { 
		print(x,matrix); 
		return true; 
	} 

	bool fin = false; 
	for (int i = 0; i < x; i++) { 
		if ( isitok(x,matrix, i, col) ) { 
			matrix[i][col] = 1; 

			fin = subsolveit(x,matrix, col + 1) || fin; 

			matrix[i][col] = 0;
		} 
	} 
	return fin; 
} 

/**
 * @brief Checks for a matrix size
 * @param x 
 */
void solveit(int x) { 
	int matrix[N][N]; 
	for(int i=0;i<x;i++)
	    for(int j=0;j<x;j++)
	        matrix[i][j]=0;

	if (subsolveit(x,matrix, 0) == false) { 
		cout<<"Solution does not exist";
		return; 
	} 
	
	return; 
} 

int main() { 
    int x;
    cout<<"Enter the size of matrix"<<endl;
    cin>>x;
	solveit(x); 
} 
