var indexSectionsWithContent =
{
  0: "abclms",
  1: "l",
  2: "cms",
  3: "abl"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables"
};

