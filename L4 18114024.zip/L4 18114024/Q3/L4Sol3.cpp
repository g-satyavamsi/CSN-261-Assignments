/**
 * @file L4Sol3.cpp
 * @author G.Satya Vamsi
 * @brief To find max sub array
 * @date 2019-09-03
 * 
 */
#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <iterator>
using namespace std;

int array[100];
int begin=0,last=0;

/**
 * @brief Finds beginning,ending indexes
 * @param arr 
 * @param index 
 * @param vec
 */
void setvalues(int arr[], int index, vector<int> vec)
{
	for (int &j: vec)
		if(index-j-1>=last-begin){
		    copy(arr + j+1, arr + index + 1,&array[0]);
		    last=index;
		    begin=j+1;
		}
}

/**
 * @brief Checks the sub array
 * @param arr 
 * @param n 
 * @param sum
 */
void checkarray(int arr[], int n, int sum)
{
	unordered_map<int, vector<int>> hmap;
	hmap[0].push_back(-1);
	int sum_present = 0;

	for (int index = 0; index < n; index++)
	{
		sum_present += arr[index];

		auto iterator = hmap.find(sum_present - sum);
		if (iterator != hmap.end())
			setvalues(arr, index, hmap[iterator->first]);

		hmap[sum_present].push_back(index);
	}
}

int main()
{
	int n;
	cin>>n;
	int arr[n];
	for(int i=0;i<n;i++)
	    cin>>arr[i];
	int sum;
	cin>>sum;

	checkarray(arr, n, sum);
	cout<<"Length of longest subarray is "<<last-begin+1;
	cout<<endl<<"Index from "<<begin<<" to "<<last;
}