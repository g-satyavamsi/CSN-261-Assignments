
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QString"
Trie* root = NULL;
/*struct Trie {
    bool isEndOfWord;
    map<char, Trie*> map;
    string meaning;
};

// Function to create a new Trie node
Trie* getNewTrieNode(){
    Trie* node = new Trie;
    node->isEndOfWord = false;
    return node;
}



void insert(Trie*& root, const string& str,const string& meaning){

    // If root is null
    if (root == NULL)
        root = getNewTrieNode();

    Trie* temp = root;
    for (int i = 0; i < str.length(); i++) {
        char x = str[i];

        // Make a new node if there is no path
        if (temp->map.find(x) == temp->map.end())
            temp->map[x] = getNewTrieNode();

        temp = temp->map[x];
    }

    // Mark end of word and store the meaning
    temp->isEndOfWord = true;
    temp->meaning = meaning;
}

string getMeaning(Trie* root, const string& word){

    // If root is null i.e. the dictionary is empty
    if (root == NULL)
        return "";

    Trie* temp = root;

    // Search a word in the Trie
    for (int i = 0; i < word.length(); i++) {
        temp = temp->map[word[i]];
        if (temp == NULL)
            return "";
    }

    // If it is the end of a valid word stored
    // before then return its meaning
    if (temp->isEndOfWord)
        return temp->meaning;
    return "No";
}*/

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);


        string one,two;
        // Build the dictionary
        FILE *fp = fopen("C:\\F files\\L4_P1_input.csv", "r");
        const char s[2] = ";";
        char *token;
        int i;
        if(fp != NULL)
        {
            char line[200];
            while(fgets(line, sizeof line, fp) != NULL)
            {
                token = strtok(line, s);
                for(i=0;i<2;i++)
                {
                    if(i==0)
                    {
                        printf("%s\t",token);
                        one=token;
                        token = strtok(NULL,s);
                    }
                    else {
                        printf("%s\n",(token));
                        two=token;
                    }
                    insert(root,one,two);
                }
            }
            fclose(fp);
        }
        else {
            perror("user.dat");
        }

        string str = "PROPS";
       // cout << getMeaning(root, str);
    QPushButton * button = MainWindow::findChild<QPushButton *>("pushButton");
    connect(button,SIGNAL(released()),this,SLOT(on_pushButton_released()));
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::on_pushButton_released()
{
    QString str =ui->plainTextEdit->toPlainText();
    string mean = getMeaning(root,str.toStdString());
    ui->textBrowser->setText(QString::fromStdString(mean));
}
