/**@file transpose.c
*@author G.Satya Vamsi
*@date Aug 06,2019
*@brief Encryption of a given .txt file
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int a,b,n;
int p=0,q=0,r;
int actual_length,pseudo_length=0;
char in[1000],i[1000],j[1000],out[1000],file_pointer;

int main(int argc,char* argv[]){
    
    n=atoi(argv[1]);
    a=atoi(argv[2]);
    b=atoi(argv[3]);
    if(n<1){
        printf("Please check your n value...");
        return;
    }

/**@file transpose.c
*@author G.Satya Vamsi
*@date Aug 06,2019
*@brief Taking input of given .txt
*/

    FILE *file_opener;
    file_opener=fopen(argv[4],"r");
    if(file_opener==NULL){
        printf("Please recheck your arguments...");
        return;
    }
    while((file_pointer=fgetc(file_opener))!=EOF){
        in[pseudo_length]=file_pointer;
        pseudo_length++;
    }
    fclose(file_opener);

    p=pseudo_length/n;
    if(pseudo_length%n==0)
        actual_length=(p)*n;
    else
        actual_length=(p+1)*n;

    p=pseudo_length;
    while(p<actual_length){
        in[p]='\0';
        p++;
    }

    p=q=0;

/**Creating i[] array**/
    while(p<actual_length){
        i[p]=q;
        q++;
        if(q==n)
            q=0;
        p++;
    }

    p=q=0;

/**Creating j[] array**/
    while(p<actual_length){
        q=(a*i[p])+b;
        q=q%n;
        j[p]=q;
        p++;
    }

    p=q=0;

/**Encrypting and creating out[] array**/
    while(p<actual_length){
        r=p/n;
        q=5*r;
        while(q<5*r+4){
            if(j[p]==i[q])
                break;
            q++;
        }
        out[p]=in[q];
        p++;
    }

/**@file transpose.c
*@author G.Satya Vamsi
*@date Aug 06,2019
*@brief Printing maximal array and its quad tree
*/

    FILE *file_writer = fopen("F:\\outputfile.txt", "w");
    if (file_writer == NULL)
    {
        printf("Error opening file!\n");
        exit(1);
    }

    q=0;
/**Writing into outtputfile.txt file**/
    while(q<actual_length){
        fprintf(file_writer,"%c",out[q]);
        q++;
    }

    fclose(file_writer);
}
