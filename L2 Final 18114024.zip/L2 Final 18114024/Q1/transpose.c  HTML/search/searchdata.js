var indexSectionsWithContent =
{
  0: "abfijnopqrt",
  1: "t",
  2: "abfijnopqr"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Variables"
};

