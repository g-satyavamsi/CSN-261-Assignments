var searchData=
[
  ['old_5fa',['old_a',['../inverse_transpose_8c.html#a6e231f668100ab44e3ff3a188b0bdb37',1,'inverseTranspose.c']]],
  ['old_5fb',['old_b',['../inverse_transpose_8c.html#a10603848d58cd69c1b0ff3823b144d88',1,'inverseTranspose.c']]],
  ['out',['out',['../inverse_transpose_8c.html#a85b1c24df003cd7ace35e8948169fcf5',1,'inverseTranspose.c']]]
];
