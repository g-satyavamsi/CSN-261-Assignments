var searchData=
[
  ['n',['n',['../inverse_transpose_8c.html#a76f11d9a0a47b94f72c2d0e77fb32240',1,'inverseTranspose.c']]],
  ['new_5fa',['new_a',['../inverse_transpose_8c.html#a7bea45d51fd9384037bbbf82f7750ce6',1,'inverseTranspose.c']]],
  ['new_5fb',['new_b',['../inverse_transpose_8c.html#a84ea92338262e59be62e15e36be2925a',1,'inverseTranspose.c']]]
];
