var searchData=
[
  ['q',['q',['../inverse_transpose_8c.html#a39ed6f33ae9187d166e4d9d69e456ff9',1,'inverseTranspose.c']]]
];
