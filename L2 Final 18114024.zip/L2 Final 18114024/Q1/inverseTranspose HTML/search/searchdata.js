var indexSectionsWithContent =
{
  0: "afijmnopqr",
  1: "i",
  2: "afijmnopqr"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Variables"
};

