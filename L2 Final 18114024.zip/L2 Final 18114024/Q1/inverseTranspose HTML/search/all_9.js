var searchData=
[
  ['r',['r',['../inverse_transpose_8c.html#acab531abaa74a7e664e3986f2522b33a',1,'inverseTranspose.c']]]
];
