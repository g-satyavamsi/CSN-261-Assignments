var searchData=
[
  ['j',['j',['../inverse_transpose_8c.html#ad71583c9e039d91177d26649e9f19741',1,'inverseTranspose.c']]]
];
