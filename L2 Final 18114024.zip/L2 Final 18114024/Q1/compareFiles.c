/**@file compareFiles.c
*@author G.Satya Vamsi
*@date Aug 06,2019
*@brief Comparing two .txt files
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char c1,c2,file1[1000],file2[1000],checker=0;
int p=0,q=0;

FILE *file_opener;
FILE *file_opener2;

int main(){
/**Opening the two .txt files**/
    file_opener=fopen("F://inputfile.txt","r");
    file_opener2=fopen("F://decryptedOutputfile.txt","r");

    if(file_opener==NULL || file_opener2==NULL){
        printf("Please check your files...");
        return;
    }
    while(((c1=fgetc(file_opener))!=EOF)&&c1!='\0'){
        file1[p]=c1;
        p++;
    }

    while(((c2=fgetc(file_opener2))!=EOF)&&c2!='\0'){
        file2[q]=c2;
        q++;
    }

/**Checking whether they are the same**/
    if(p!=q){
        checker=1;
        printf("\nThe files are not same");
    }

    else{
        q=0;
        while(q<p){
            if(file1[q]!=file2[q]){
                checker=1;
                printf("\nThe files are not same");
                break;
            }
            q++;
        }
    }

    if(checker==0)
        printf("\nBoth the files are same\n");

    fclose(file_opener);
    fclose(file_opener2);

}
