/**@file inverseTranspose.c
*@author G.Satya Vamsi
*@date Aug 06,2019
*@brief Decryption of a given .txt file
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int new_a,new_b,n,old_a,old_b,multi=0;
int p=0,r,pseudo_n,q=0;
int actual_length,pseudo_length=0;
char in[1000],i[1000],j[1000],out[1000],file_pointer;

int main(int argc,char* argv[]){
	
    n=atoi(argv[1]);
    old_a=atoi(argv[2]);
    old_b=atoi(argv[3]);
    pseudo_n=n;
    if(n<1){
        printf("Please check your n value...");
        return;
    }
    while(a<0)
    	old_a=old_a+n;
    while(b<0)
    	old_b=old_b+n;

/**Finding new values of a and b**/
    while(multi<n){
        if((multi*n+1)%old_a==0){
            new_a=(multi*n+1)/old_a;
            new_b=n-((new_a*old_b)%n);
            break;
        }
        multi++;
    }

/**@file inverseTranspose.c
*@author G.Satya Vamsi
*@date Aug 06,2019
*@brief Reading the code from .txt file
*/
    FILE *file_opener;
    file_opener=fopen("F://outputfile.txt","r");
    if(file_opener==NULL){
        printf("Please recheck your arguments...");
        return;
    }
    while((file_pointer=fgetc(file_opener))!=EOF){
        in[pseudo_length]=file_pointer;
        pseudo_length++;
    }
    fclose(file_opener);

/**Finding new length of array**/
	p=pseudo_length/n;
	if(pseudo_length%n==0)
        actual_length=(p)*n;
	else
        actual_length=(p+1)*n;

	p=pseudo_length;
	while(p<actual_length){
	    in[p]='\0';
	    p++;
	}

	p=q=0;

/**Finding i[] array**/
	while(p<actual_length){
		i[p]=q;
		q++;
		if(q==n)
			q=0;
		p++;
	}

	p=q=0;

/**Finding j[] array**/
	while(p<actual_length){
		q=(new_a*i[p])+new_b;
		q=q%n;
		j[p]=q;
		p++;
	}

	p=q=0;

/**Finding out[] array**/
	while(p<actual_length){
		r=p/n;
		q=5*r;
		while(q<5*r+4){
			if(j[p]==i[q])
				break;
			q++;
		}
		out[p]=in[q];
		p++;
	}

/**@file inverseTranspose.c
*@author G.Satya Vamsi
*@date Aug 06,2019
*@brief Decryption of a given .txt file
*/
	FILE *file_writer = fopen("F:\\decryptedOutputfile.txt", "w");
	if (file_writer == NULL)
	{
	    printf("Error opening file!\n");
	    exit(1);
	}

	q=0;
/**Writing decrypted code into a .txt file**/
	while(q<pseudo_length){
        fprintf(file_writer,"%c",out[q]);
        q++;
	}
	fclose(file_writer);

	printf("New file decryptedOutputfile.txt is created");
}
