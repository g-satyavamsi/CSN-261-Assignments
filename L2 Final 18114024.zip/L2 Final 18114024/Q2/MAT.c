/**@file L2Q2Final.c
*@author G.Satya Vamsi
*@date Aug 06,2019
*@brief Printing maximal array and its quad tree
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

int i,j,b,ii=0,jj=0,p;
int merged_value=1;
int count1,count2=0,count3;
int row_lower,row_upper,column_lower,column_upper;

/**@file L2Q2Final.c
*@author G.Satya Vamsi
*@date Aug 06,2019
*@brief Function to find nearest power of 2
*@param An integer
*/

int power_finder(int a){
    count3=0;
    p=1;
    while(p<a){
        p=p*2;
        count3++;
    }
    return count3;
}

/**@file L2Q2Final.c
*@author G.Satya Vamsi
*@date Aug 06,2019
*@brief Checks whether all elements are equal
*@param An array
*/

bool isitok(int r,int c,int a[r][c],int row_lower,int row_upper,int column_lower,int column_upper){
    count1=0;
    for(i=row_lower;i<row_upper;i++){
        for(j=column_lower;j<column_upper;j++){
            if(a[i][j]==a[row_lower][column_lower])
                count1++;
        }
    }
    if(count1==(row_upper-row_lower)*(row_upper-row_lower))
        return true;
    else
        return false;
}

/**@file L2Q2Final.c
*@author G.Satya Vamsi
*@date Aug 06,2019
*@brief Creating the maximal array
*@param An array
*/

void perform(int r,int c,int a[r][c],int row_lower,int row_upper,int column_lower,int column_upper){
    if(isitok(r,c,a,row_lower,row_upper,column_lower,column_upper)){
        for(i=row_lower;i<row_upper;i++)
            for(j=column_lower;j<column_upper;j++)
                a[i][j]=merged_value;
        merged_value++;
    }
/**Sending through recursion**/
    else{
        perform(r,c,a,row_lower,(row_lower+row_upper)/2,column_lower,(column_lower+column_upper)/2);
        perform(r,c,a,row_lower,(row_lower+row_upper)/2,(column_lower+column_upper)/2,column_upper);
        perform(r,c,a,(row_lower+row_upper)/2,row_upper,column_lower,(column_lower+column_upper)/2);
        perform(r,c,a,(row_lower+row_upper)/2,row_upper,(column_lower+column_upper)/2,column_upper);
    }

}

int main(){
    int file_pointer,diff,maximalarray_size=1,originalarray_size=0;

/**@file L2Q2Final.c
*@author G.Satya Vamsi
*@date Aug 06,2019
*@brief Takes input from .txt file and creates binary array
*/
    FILE *file_opener;
    file_opener=fopen("F://Array.txt","r");
    if(file_opener==NULL){
        printf("Please check your input file...");
        return;
    }
    while((file_pointer=fgetc(file_opener))!=EOF){
        if(file_pointer==48||file_pointer==49)
            originalarray_size++;
        if(file_pointer==10)
            break;
    }
    fclose(file_opener);

    int original_array[originalarray_size][originalarray_size];

    i=j=0;
    FILE *file_opener2;
    file_opener2=fopen("F://Array.txt","r");
    while((file_pointer=fgetc(file_opener2))!=EOF){
        if(file_pointer==48){
            original_array[i][j]=0;
            j++;
        }
        else if(file_pointer==49){
            original_array[i][j]=1;
            j++;
        }
        if(j==originalarray_size){
            j=0;
            i++;
        }
    }
    fclose(file_opener);

    if(originalarray_size==0){
        printf("At least one element should be present...");
        return;
    }

/**Finding size of maximal array**/
    while(maximalarray_size<originalarray_size){
        maximalarray_size=maximalarray_size*2;
    }

    diff=maximalarray_size-originalarray_size;

    int binary_array[maximalarray_size][maximalarray_size];
    for(i=0;i<maximalarray_size;i++){
        for(j=0;j<maximalarray_size;j++){
            if(i<diff||j<diff)
                binary_array[i][j]=0;
            else
                binary_array[i][j]=original_array[i-diff][j-diff];
        }
    }

    int maximal_array[maximalarray_size][maximalarray_size];
    for(i=0;i<maximalarray_size;i++){
        for(j=0;j<maximalarray_size;j++){
            maximal_array[i][j]=binary_array[i][j];
        }
    }
/**Printing binary array**/
    printf("\nBinary array is:\n");
    for(i=0;i<maximalarray_size;i++){
        for(j=0;j<maximalarray_size;j++){
            printf("%d ",binary_array[i][j]);
        }
        printf("\n");
    }

    perform(maximalarray_size,maximalarray_size,maximal_array,0,maximalarray_size,0,maximalarray_size);

    printf("\nMaximal array is:\n");
    for(i=0;i<maximalarray_size;i++){
        for(j=0;j<maximalarray_size;j++){
            printf("%d ",maximal_array[i][j]);
        }
    printf("\n");
    }

/**@file L2Q2Final.c
*@author G.Satya Vamsi
*@date Aug 06,2019
*@brief Printing nodes
*/
    printf("\nThe quad tree in nodal representation:\n");
    for(b=1;b>0;b++){
        count2=0;
        for(i=0;i<maximalarray_size;i++){
            for(j=0;j<maximalarray_size;j++){
                if(maximal_array[i][j]==b){
                    count2++;
                     ii=i;
                     jj=j;
                }
            }
        }
        if(count2==0)
            break;
        else{
            count2=pow(count2,0.5);
            count2=maximalarray_size/count2;
            count2=power_finder(count2);
            printf("\n\(%d,%d,%d\)",b,binary_array[ii][jj],count2);
        }
    }

}
