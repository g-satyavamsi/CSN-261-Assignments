var searchData=
[
  ['column_5flower',['column_lower',['../_m_a_t_8c.html#a8e5fdf1b642ea10069bdb8b3a8631239',1,'MAT.c']]],
  ['column_5fupper',['column_upper',['../_m_a_t_8c.html#a0089b9457f3ca72e592d8ce9415bd737',1,'MAT.c']]],
  ['count1',['count1',['../_m_a_t_8c.html#aa8b6f15b372c722be08179e285658d86',1,'MAT.c']]],
  ['count2',['count2',['../_m_a_t_8c.html#a352f103b4480374c5e8ae3e132d4e958',1,'MAT.c']]],
  ['count3',['count3',['../_m_a_t_8c.html#a37d10b68a9b51c8d84d9f75e6927f2ed',1,'MAT.c']]]
];
