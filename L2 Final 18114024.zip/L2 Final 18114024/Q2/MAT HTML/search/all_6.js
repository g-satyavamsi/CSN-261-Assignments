var searchData=
[
  ['row_5flower',['row_lower',['../_m_a_t_8c.html#af1211dad482ea37942f9c1d3f896d8bf',1,'MAT.c']]],
  ['row_5fupper',['row_upper',['../_m_a_t_8c.html#a7ac5fa0687b457401e9debacc5ce3725',1,'MAT.c']]]
];
