var searchData=
[
  ['perform',['perform',['../_m_a_t_8c.html#a46baa160057cb47729ae0f679a71f699',1,'MAT.c']]],
  ['power_5ffinder',['power_finder',['../_m_a_t_8c.html#a519d9cd5a86938398b0f21d93d48b434',1,'MAT.c']]]
];
