var searchData=
[
  ['j',['j',['../_m_a_t_8c.html#a37d972ae0b47b9099e30983131d31916',1,'MAT.c']]],
  ['jj',['jj',['../_m_a_t_8c.html#a166eef233a4fd5f1f1d611e566a40f57',1,'MAT.c']]]
];
