/**file L1Q1Final.c
*@author G.Satya Vamsi
*@task read student data and create a circular linked list
*@dated 30-Jul-2019
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**file L1Q1Final.c
*@author G.Satya Vamsi
*@function Creating a node class with various data fields and previous,next pointers
*@dated 30-Jul-2019
*/
struct node{
	int roll_numb;
	char name[100];
	char date_of_birth[100];
	char address[100];
	char phone_no[100];
	struct node* next_ptr;
	struct node* prev_ptr;
};

/**file L1Q1Final.c
*@author G.Satya Vamsi
*@function Creating some temporary pointers and variables
*@dated 30-Jul-2019
*/
struct node* ptr1=NULL;
struct node* head;
int i,deleted_rolls,assign_deleted_rolls=0,front=-1,rear=-1;
int unusedRollNo[100];
char* actual_string;
char semicolon[2]=";";

/**file L1Q1Final.c
*@author G.Satya Vamsi
*@function A function that accesses the data field of given person
*@dated 30-Jul-2019
*/
void assign_string_sub(char new_line[],int x,char d[]){
	char *string_break = strtok(new_line,semicolon);
	int column_counter=0;
	while( string_break!=NULL){
		column_counter++;
		if(column_counter==x){
			actual_string=string_break;
			strcpy(d,actual_string);
			return;
		}
		string_break = strtok(NULL,semicolon);
	}
}

/**file L1Q1Final.c
*@author G.Satya Vamsi
*@function A function that accesses the person
*@dated 30-Jul-2019
*/
void assign_string(char d[],int x,int y){
	FILE *file_opener = fopen("F:\\StudentDataxlsx.csv","r");
    int row_counter=-1;
	while((getc(file_opener))!=EOF){
		char new_line[1024];
		fgets(new_line, 1024, (FILE*)file_opener);
		row_counter++;
		if(row_counter==x)
			assign_string_sub(new_line,y,d);
	}
	if(file_opener=NULL){
		perror("Please enter correct file location");
	}
}

/**file L1Q1Final.c
*@author G.Satya Vamsi
*@function A function that assigns data to different data fields
*@dated 30-Jul-2019
*/
void node_data(struct node* newnode,int x){
	if(x>=1 || x<=9){
		assign_string(newnode->name,x,1);
		assign_string(newnode->date_of_birth,x,2);
		assign_string(newnode->address,x,3);
		assign_string(newnode->phone_no,x,4);
	}
	if(x>9 || x<=13){
		assign_string(newnode->name,x,2);
		assign_string(newnode->date_of_birth,x,3);
		assign_string(newnode->address,x,4);
		assign_string(newnode->phone_no,x,5);
	}
}

/**file L1Q1Final.c
*@author G.Satya Vamsi
*@function Insertion operation for unusedRollNo queue
*@dated 30-Jul-2019
*/
void insertqueue(int x){
	if(front==-1)
		front++;
	rear++;
	unusedRollNo[rear]=x;
}

/**file L1Q1Final.c
*@author G.Satya Vamsi
*@function Deletion operation for unusedRollNo queue
*@dated 30-Jul-2019
*/
void deletequeue(){
	if(front==-1)
		deleted_rolls=0;
	else{
		deleted_rolls=unusedRollNo[front];
		front++;
		if(front>rear)
			front=rear=-1;
	}
	return;
}

void swap(char a[],char b[]){
    char c[100];
    strcpy(c,a);
    strcpy(a,b);
    strcpy(b,c);
}

/**file L1Q1Final.c
*@author G.Satya Vamsi
*@function Function that swaps data of two nodes
*@dated 30-Jul-2019
*/
void swapnode(struct node* p1,struct node* p2){
	int a;
	a=p1->roll_numb;
	p1->roll_numb=p2->roll_numb;
	p2->roll_numb=a;
	swap(p1->name,p2->name);
	swap(p1->date_of_birth,p2->date_of_birth);
	swap(p1->address,p2->address);
	swap(p1->phone_no,p2->phone_no);
}

/**file L1Q1Final.c
*@author G.Satya Vamsi
*@function A function to sort all according to their name
*@dated 30-Jul-2019
*/
void sort(){
	struct node* temp1=head;
	struct node* temp2=head;
	while(temp1->next_ptr!=head)
		temp1=temp1->next_ptr;
	while(temp1!=head){
		temp2=head;
		while(temp2!=temp1){
			if(strcmp((temp2->name),(temp2->next_ptr)->name)>0)
				swapnode(temp2,temp2->next_ptr);
			temp2=temp2->next_ptr;
		}
	temp1=temp1->prev_ptr;
	}
}

/**file L1Q1Final.c
*@author G.Satya Vamsi
*@function A function that inserts a new person
*@dated 30-Jul-2019
*/
void insert(int x){
    struct node* ptr=head;
	if(head==NULL){
		struct node* newnode=(struct node*)malloc(sizeof(struct node));
		newnode->roll_numb=101;
		node_data(newnode,x);
		newnode->next_ptr=newnode;
		newnode->prev_ptr=newnode;
		head=newnode;
		return;
	}
	else{
		struct node* newnode=(struct node*)malloc(sizeof(struct node));
	while(ptr->next_ptr!=head)
		ptr=ptr->next_ptr;
	node_data(newnode,x);
	ptr->next_ptr=newnode;
	newnode->prev_ptr=ptr;
	newnode->next_ptr=head;
	head->prev_ptr=newnode;
	ptr1=head;
	deletequeue();
	if(deleted_rolls==0){
        assign_deleted_rolls=head->roll_numb;
        while(ptr1!=newnode){
            if((ptr1->roll_numb)>assign_deleted_rolls)
                assign_deleted_rolls=ptr1->roll_numb;
            ptr1=ptr1->next_ptr;
        }
        newnode->roll_numb=assign_deleted_rolls+1;
	}
	else
		newnode->roll_numb=deleted_rolls;
	}
}

/**file L1Q1Final.c
*@author G.Satya Vamsi
*@function A function to modify various data fields of a person
*@dated 30-Jul-2019
*/
void modify(int x,int y,char g[]){
    struct node* temp1;
    temp1=head;
    for(i=1;i<x;i++)
        temp1=temp1->next_ptr;
    if(y==1)
        strcpy(temp1->name,g);
    if(y==2)
        strcpy(temp1->date_of_birth,g);
    if(y==3)
        strcpy(temp1->address,g);
    if(y==4)
        strcpy(temp1->phone_no,g);
}

/**file L1Q1Final.c
*@author G.Satya Vamsi
*@function A function that deletes a person
*@dated 30-Jul-2019
*/
void delnode(int x){
	if(head=NULL)
		printf("Queue is empty");
	struct node* temp=head;
	while(temp->roll_numb!=x)
		temp=temp->next_ptr;
	struct node* prev1=temp->prev_ptr;
	struct node* next1=temp->next_ptr;
	insertqueue(temp->roll_numb);
	prev1->next_ptr=next1;
	next1->prev_ptr=prev1;
	temp=prev1=next1=NULL;
	free(temp);
}

/**file L1Q1Final.c
*@author G.Satya Vamsi
*@function A function to search a person as per their roll
*@dated 30-Jul-2019
*/
void search(int x){
	struct node* temp2=head;
	while(temp2->roll_numb!=x){
		temp2=temp2->next_ptr;
	}
	printf("\nRequired Person-\nRoll no.:%d\nName:%s\nDOB:%s\nAddress:%s\nPhone no.:%s\n",temp2->roll_numb,temp2->name,temp2->date_of_birth,temp2->address,temp2->phone_no);
}

/**file L1Q1Final.c
*@author G.Satya Vamsi
*@function A function that displays whole list
*@dated 30-Jul-2019
*/
void display(){
	struct node* ptr=head;
	while(ptr->next_ptr!=head){
		printf("\nRoll no.:%d\nName:%s\nDOB:%s\nAddress:%s\nPhone no.:%s\n",ptr->roll_numb,ptr->name,ptr->date_of_birth,ptr->address,ptr->phone_no);
		ptr=ptr->next_ptr;
	}
	printf("\nRoll no.:%d\nName:%s\nDOB:%s\nAddress:%s\nPhone no.:%s\n",ptr->roll_numb,ptr->name,ptr->date_of_birth,ptr->address,ptr->phone_no);
}

int main(){
	int order,v1,v2,v4=2;
	char v3[100];
	while(v4>0){
        printf("\nWhat do you want?\n1.Insertion\n2.Deletion\n3.Search\n4.Modify\n5.Sorting\n6.Printing\n7.Exit\n");
        scanf("%d",&order); /*Takes various orders from user*/
        if(order==1){
            printf("\nEnter serial no. of person\n");
            scanf("%d",&v1);
            insert(v1);
        }
        else if(order==2){
            printf("\nEnter roll no. of person you want to delete\n");
            scanf("%d",v1);
            delnode(v1);
        }
        else if(order==3){
            printf("\nEnter roll no. of person whom you want to search\n");
            scanf("%d",v1);
            search(v1);
        }
        else if(order==4){
            printf("\nEnter roll no. of person whose details you want to modify\n");
            scanf("%d",v1);
            printf("\nWhat do you Want to modify?\n1.Name\n2.Date of birth\n3.Address\n4.Phone no.\n");
            scanf("%d",v2);
            printf("\nEnter the new value\n");
            scanf("%s",v3);
            modify(v1,v2,v3);
        }
        else if(order==5){
            sort();
        }
        else if(order==6){
            display();
        }
        else if(order==7){
            break;
        }
	}
}
