var searchData=
[
  ['phone_5fno',['phone_no',['../structnode.html#a521eb4bda3d53df9dcec736615244aaf',1,'node']]],
  ['prev_5fptr',['prev_ptr',['../structnode.html#a23fe26f076b822d6482817c5a59ea080',1,'node']]],
  ['ptr1',['ptr1',['../_l1_q1_final_8c.html#aff9139f94d04ad93c88766f974112b0e',1,'L1Q1Final.c']]]
];
