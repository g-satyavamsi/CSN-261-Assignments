var searchData=
[
  ['date_5fof_5fbirth',['date_of_birth',['../structnode.html#a3f097ab19d1830f02fb48fa4191e7ae6',1,'node']]],
  ['deleted_5frolls',['deleted_rolls',['../_l1_q1_final_8c.html#a7d5d3cf856ef4049e5f3378709297790',1,'L1Q1Final.c']]]
];
