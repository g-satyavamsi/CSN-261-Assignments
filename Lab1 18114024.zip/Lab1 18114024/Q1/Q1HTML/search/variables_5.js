var searchData=
[
  ['name',['name',['../structnode.html#aeaf846aa21a7d016a52f0b5b0c2f5544',1,'node']]],
  ['next_5fptr',['next_ptr',['../structnode.html#aca8c861b74869fc738948b33e4edcb8e',1,'node']]]
];
