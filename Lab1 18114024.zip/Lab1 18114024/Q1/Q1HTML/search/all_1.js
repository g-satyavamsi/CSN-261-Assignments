var searchData=
[
  ['date_5fof_5fbirth',['date_of_birth',['../structnode.html#a3f097ab19d1830f02fb48fa4191e7ae6',1,'node']]],
  ['deleted_5frolls',['deleted_rolls',['../_l1_q1_final_8c.html#a7d5d3cf856ef4049e5f3378709297790',1,'L1Q1Final.c']]],
  ['deletequeue',['deletequeue',['../_l1_q1_final_8c.html#a941955e51bfb6d126e438e1650d7928a',1,'L1Q1Final.c']]],
  ['delnode',['delnode',['../_l1_q1_final_8c.html#aa80964bd5c7dbba0b3de3c89056c3f43',1,'L1Q1Final.c']]],
  ['display',['display',['../_l1_q1_final_8c.html#a1e5b20fed15743656bb6d2e6a6ea6269',1,'L1Q1Final.c']]]
];
