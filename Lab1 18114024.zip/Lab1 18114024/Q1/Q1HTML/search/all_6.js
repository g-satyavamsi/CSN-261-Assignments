var searchData=
[
  ['main',['main',['../_l1_q1_final_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'L1Q1Final.c']]],
  ['modify',['modify',['../_l1_q1_final_8c.html#a76d7d21d97180d639c12bf1077abd12f',1,'L1Q1Final.c']]]
];
