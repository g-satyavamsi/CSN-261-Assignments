var searchData=
[
  ['name',['name',['../structnode.html#aeaf846aa21a7d016a52f0b5b0c2f5544',1,'node']]],
  ['next_5fptr',['next_ptr',['../structnode.html#aca8c861b74869fc738948b33e4edcb8e',1,'node']]],
  ['node',['node',['../structnode.html',1,'']]],
  ['node_5fdata',['node_data',['../_l1_q1_final_8c.html#a91a3b612515c7cbe5ab74418911526e9',1,'L1Q1Final.c']]]
];
