var structnode =
[
    [ "address", "structnode.html#adb29a9861a3fc56213185df8b106f9ef", null ],
    [ "date_of_birth", "structnode.html#a3f097ab19d1830f02fb48fa4191e7ae6", null ],
    [ "name", "structnode.html#aeaf846aa21a7d016a52f0b5b0c2f5544", null ],
    [ "next_ptr", "structnode.html#aca8c861b74869fc738948b33e4edcb8e", null ],
    [ "phone_no", "structnode.html#a521eb4bda3d53df9dcec736615244aaf", null ],
    [ "prev_ptr", "structnode.html#a23fe26f076b822d6482817c5a59ea080", null ],
    [ "roll_numb", "structnode.html#a4aa210e887d6c4424e762530d8ff27ce", null ]
];