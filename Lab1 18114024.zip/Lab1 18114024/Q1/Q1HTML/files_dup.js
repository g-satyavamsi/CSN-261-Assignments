var files_dup =
[
    [ "dq1", "dir_80015928b95ff24657e9b8b426e8541d.html", "dir_80015928b95ff24657e9b8b426e8541d" ]
];