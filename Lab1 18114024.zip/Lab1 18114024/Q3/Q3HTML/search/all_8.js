var searchData=
[
  ['pixelvalue',['pixelvalue',['../_l1_q3_final_8c.html#a2f116268594e61ee06542bb24c25ba62',1,'L1Q3Final.c']]]
];
