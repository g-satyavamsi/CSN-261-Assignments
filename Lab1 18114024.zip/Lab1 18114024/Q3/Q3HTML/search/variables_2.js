var searchData=
[
  ['greenpixel',['greenpixel',['../_l1_q3_final_8c.html#aef6a0e29547b3011a0bbe7102c74c716',1,'L1Q3Final.c']]]
];
