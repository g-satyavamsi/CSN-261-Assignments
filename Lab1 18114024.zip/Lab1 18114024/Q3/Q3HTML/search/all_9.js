var searchData=
[
  ['redpixel',['redpixel',['../_l1_q3_final_8c.html#ac9855f1c83bddc606a3f7174b05c2af8',1,'L1Q3Final.c']]]
];
