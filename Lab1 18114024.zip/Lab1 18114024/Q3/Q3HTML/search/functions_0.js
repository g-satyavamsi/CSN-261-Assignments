var searchData=
[
  ['get_5fbluepixel',['get_bluepixel',['../_l1_q3_final_8c.html#a58a2e33de9c0d5275da7a9eb360bbcc6',1,'L1Q3Final.c']]],
  ['get_5fgreenpixel',['get_greenpixel',['../_l1_q3_final_8c.html#ada2f375c6603919719cb7c53a5270cdf',1,'L1Q3Final.c']]],
  ['get_5fredpixel',['get_redpixel',['../_l1_q3_final_8c.html#a1d0de0dd6abab5796ca90a5640000b76',1,'L1Q3Final.c']]]
];
