var indexSectionsWithContent =
{
  0: "bcgijlmopr",
  1: "l",
  2: "gmp",
  3: "bcgijor"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables"
};

