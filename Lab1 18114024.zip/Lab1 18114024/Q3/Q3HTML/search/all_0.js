var searchData=
[
  ['bluepixel',['bluepixel',['../_l1_q3_final_8c.html#a29233a705f905a076e515f56adbc34f6',1,'L1Q3Final.c']]]
];
