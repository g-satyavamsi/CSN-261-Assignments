/**file L1Q3Final.c
*@author G.Satya Vamsi
*@task read pixels and modify them
*@dated 30-Jul-2019
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int order,redpixel=0,greenpixel=0,bluepixel=0,i=0,j;
const char comma[2] = ",";

/**file L1Q3Final.c
*@author G.Satya Vamsi
*@function A function that is used to read red pixel value from red pixel file
*@dated 30-Jul-2019
*/
void get_redpixel(int x,int y){
    j=0;
    FILE *file_opener = fopen("f:/Q3_ip_Red.dat", "r"); /*Please enter the exact file location*/
    char *segment;
    if(file_opener != NULL){
        char line[4];
        while(fgets(line, sizeof line, file_opener) != NULL){
            segment = strtok(line, comma);
            if(j==1268*x+y)  /*Goes to the required co-ordinate*/
                redpixel=atoi(segment);
            j++;
            segment = strtok(NULL,comma);
        }
        fclose(file_opener);
    }
    else
        perror("Please re check your file location");
}

/**file L1Q3Final.c
*@author G.Satya Vamsi
*@function A function that is used to read green pixel value from green pixel file
*@dated 30-Jul-2019
*/
void get_greenpixel(int x,int y){
    j=0;
    FILE *file_opener = fopen("f:/Q3_ip_Green.dat", "r"); /*Please enter the exact file location*/
    char *segment;
    if(file_opener != NULL){
        char line[4];
        while(fgets(line, sizeof line, file_opener) != NULL){
            segment = strtok(line, comma);
            if(j==1268*x+y)  /*Goes to the required co-ordinate*/
                greenpixel=atoi(segment);
            j++;
            segment = strtok(NULL,comma);
        }
        fclose(file_opener);
    }
    else
        perror("Please re check your file location");
}

/**file L1Q3Final.c
*@author G.Satya Vamsi
*@function A function that is used to read blue pixel value from blue pixel file
*@dated 30-Jul-2019
*/
void get_bluepixel(int x,int y){
    j=0;
    FILE *file_opener = fopen("f:/Q3_ip_Blue.dat", "r"); /*Please enter the exact file location*/
    char *segment;
    if(file_opener != NULL){
        char line[4];
        while(fgets(line, sizeof line, file_opener) != NULL){
            segment = strtok(line, comma);
            if(j==1268*x+y)  /*Goes to the required co-ordinate*/
                bluepixel=atoi(segment);
            j++;
            segment = strtok(NULL,comma);
        }
        fclose(file_opener);
    }
    else
        perror("Please re check your file location");
}

/**file L1Q3Final.c
*@author G.Satya Vamsi
*@function A function that assigns r,g,b pixel values
*@dated 30-Jul-2019
*/
void pixelvalue(int order,int x,int y){
    get_redpixel(x,y);  /*Calling file reading functions*/
    get_greenpixel(x,y);
    get_bluepixel(x,y);
    if(order==1){  /*Depending on input performs various tasks*/
        if(redpixel>greenpixel && redpixel>bluepixel)
            redpixel=0;
    }
    if(order==2){
        if(greenpixel>redpixel && greenpixel>bluepixel)
            greenpixel=0;
    }
    if(order==3){
        if(bluepixel>redpixel && bluepixel>greenpixel)
            bluepixel=0;
    }
    if(order==4){
        if(redpixel>greenpixel && redpixel>bluepixel)
            greenpixel=bluepixel=0;
    }
    if(order==5){
        if(greenpixel>redpixel && greenpixel>bluepixel)
            redpixel=bluepixel=0;
    }
    if(order==6){
        if(bluepixel>redpixel && bluepixel>greenpixel)
            redpixel=greenpixel=0;
    }
}

int main(){
    int x_value,y_value;
    printf("Which operation do you want?\n0.Present values\n1.Remove all Red shades\n2.Remove all Green shades\n3.Remove all Blue shades\n4.RedOnly\n5.GreenOnly\n6.BlueOnly\n");
    scanf("%d",&order);  /*Takes this as given task*/
    printf("\nEnter x and y co-ordinates of point you want\n");
    scanf("%d",&x_value);
    scanf("%d",&y_value);
    pixelvalue(order,x_value,y_value);
    printf("\nNew Red Pixel Value is : %d\nNew Green Pixel Value is : %d\nNew Blue Pixel Value is : %d",redpixel,greenpixel,bluepixel);
}
