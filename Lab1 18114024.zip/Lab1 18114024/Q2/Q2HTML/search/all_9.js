var searchData=
[
  ['updatecapacity',['updatecapacity',['../_l1_q2_final_8c.html#a99f3505883dfc5aae38309e2475ba224',1,'L1Q2Final.c']]],
  ['updatesize',['updatesize',['../_l1_q2_final_8c.html#a7598ef94a713ad04695cd1fc122fe986',1,'L1Q2Final.c']]]
];
