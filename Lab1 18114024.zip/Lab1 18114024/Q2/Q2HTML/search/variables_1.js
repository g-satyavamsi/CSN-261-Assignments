var searchData=
[
  ['data',['data',['../structnode.html#a9eab91667db4d35c7231dcddf7b89a76',1,'node']]]
];
