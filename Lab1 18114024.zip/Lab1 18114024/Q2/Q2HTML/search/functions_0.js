var searchData=
[
  ['delend',['delend',['../_l1_q2_final_8c.html#a64a822d398b15b31cde95a9a430e05ea',1,'L1Q2Final.c']]],
  ['delfront',['delfront',['../_l1_q2_final_8c.html#a5fae0a291975ae440096c224f4fe7b0d',1,'L1Q2Final.c']]]
];
