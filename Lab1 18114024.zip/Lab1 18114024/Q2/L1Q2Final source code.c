/**file L1Q2Final.c
*@author G.Satya Vamsi
*@task make a dequeue
*@dated 30-Jul-2019
*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

/**file L1Q2Final.c
*@author G.Satya Vamsi
*@function Creating a node with fields data and link pointer that points to next variable
*@dated 30-Jul-2019
*/
struct node{
	int data;
	struct node* link;
};

/**file L1Q2Final.c
*@author G.Satya Vamsi
*@function Creating front and rear pointers for the queue
*@dated 30-Jul-2019
*/
struct node* front1;
struct node* rear1;
struct node* front2;
struct node* rear2;
int i,len=0,cap=0;

/**file L1Q2Final.c
*@author G.Satya Vamsi
*@function A void return type class that updates the size of dequeue
*@dated 30-Jul-2019
*/
void updatesize(){
    len=0;
	struct node* temp=front1;
	if(front1==NULL){
	    len=0;
	    return;
	}
	else if(front1==rear1){
	    len=1;
	    return;
	}
	else if(front1!=rear1){
	    len=1;
		for(i=1;temp!=rear1;i++){
			temp=temp->link;
			len=len+1;
		}
		return;
	}
}

/**file L1Q2Final.c
*@author G.Satya Vamsi
*@function A class to print the size of dequeue
*@dated 30-Jul-2019
*/
void printsize(){
	updatesize();
	printf("\nQueue size is: %d",len);
}

/**file L1Q2Final.c
*@author G.Satya Vamsi
*@function A class that updats capacity of dequeue
*@dated 30-Jul-2019
*/
void updatecapacity(){
    cap=0;
    struct node* temp=front2;
    if(front2==NULL) cap=0;
    else if(front2==rear2) cap=1;
    else if(front2!=rear2){
        cap=1;
		for(i=1;temp!=rear2;i++){
			temp=temp->link;
			cap=cap+1;
		}
    }

}

/**file L1Q2Final.c
*@author G.Satya Vamsi
*@function A class to print the capacity of dequeue
*@dated 30-Jul-2019
*/
void printcapacity(){
    updatecapacity();
    printf("\nQueue capacity is: %d",cap);
}

/**file L1Q2Final.c
*@author G.Satya Vamsi
*@function A class that checks whether queue is full
*@dated 30-Jul-2019
*/
bool isitfull(){
    updatesize();
	updatecapacity();
	if(len==cap)
		return true;
	else
		return false;
}

/**file L1Q2Final.c
*@author G.Satya Vamsi
*@function A class to print all the elements of queue,its size and capacity
*@dated 30-Jul-2019
*/
void print(){
	if(front1==NULL)
		printf("\nQueue is empty");
	else if(front1==rear1)
		printf("\n%d",front1->data);
	else if(front1!=rear1){
		struct node* temp=front1;
		while(temp!=rear1){
			printf("\n%d",temp->data);
			temp=temp->link;
		}
		printf("\n%d",rear1->data);
	}
	updatecapacity();
	updatesize();
	printf("\nQueue size is %d",len);
	printf("\nQueue capacity is %d",cap);
}

/**file L1Q2Final.c
*@author G.Satya Vamsi
*@function A class that inserts a new element at end
*@dated 30-Jul-2019
*/
void insertrear(int x){
	struct node* temp;
	updatesize();
	updatecapacity();
	if(front1==NULL){
		struct node* newnode=(struct node*)malloc(sizeof(struct node));
		newnode->data=x;
		front1=newnode;
		rear1=newnode;
		front2=newnode;
		rear2=newnode;
		updatesize();
	}
	else if(front1!=NULL){
		if(rear1!=rear2){
			rear1=rear1->link;
			rear1->data=x;
			temp=rear1;
		}
		else if(rear1=rear2){
			struct node* newnode=(struct node*)malloc(sizeof(struct node));
			newnode->data=x;
			rear1->link=newnode;
			rear1=newnode;
			rear2=newnode;
		}
	}
	/*If queue is full its capacity doubles here*/
	if(isitfull()){
		struct node* temp=rear1;
		struct node* newnode=(struct node*)malloc(sizeof(struct node));
		rear1->link=newnode;
		temp=newnode;
		for(i=1;i<len;i++){
			struct node* newnode=(struct node*)malloc(sizeof(struct node));
			temp->link=newnode;
			temp=newnode;rear2=newnode;
		}
		updatecapacity();
	}
}

/**file L1Q2Final.c
*@author G.Satya Vamsi
*@function A class that inserts a new element at front
*@dated 30-Jul-2019
*/
void insertfront(int x){
	if(front1==NULL){
		struct node* newnode=(struct node*)malloc(sizeof(struct node));
		newnode->data=x;
		front1=newnode;
		rear1=newnode;
		front2=newnode;
		rear2=newnode;
	}
	else if(front1!=NULL){
		struct node* temp;
		if(front2!=front1){
			temp=front2;
			while(temp->link!=front1)
				temp=temp->link;
			temp->data=x;
			front1=temp;
		}
		else if(front2=front1){
			struct node* newnode=(struct node*)malloc(sizeof(struct node));
			newnode->data=x;
			newnode->link=front1;
			front1=newnode;
			front2=newnode;
		}
		/*If queue is full its capacity doubles here*/
		if(isitfull()){
			struct node* temp=rear1;
			for(i=1;i<len;i++){
				struct node* newnode=(struct node*)malloc(sizeof(struct node));
				temp->link=newnode;
				temp=newnode;
			}
			rear2=temp;
		}
	}
}

/**file L1Q2Final.c
*@author G.Satya Vamsi
*@function A class that deletes the last element
*@dated 30-Jul-2019
*/
void delend(){
	struct node* temp;
	if(front1==NULL)
		printf("Queue is empty");
	else{
		temp=front1;
		struct node* newnode=(struct node*)malloc(sizeof(struct node));
		while(temp->link!=rear1)
			temp=temp->link;
		temp->link=newnode;
		newnode->link=rear1->link;
		rear1=temp;
	}
	updatesize();
	updatecapacity();
	/*If size is half the capacity,then capacity becomes half*/
	if(cap==2*len){
		rear1->link=NULL;
		rear2=rear1;
		temp=front2;
		if(front2!=front1){
			while(temp->link!=front1)
				temp=temp->link;
			temp->link=NULL;
			front2=front1;
		}
	}
}

/**file L1Q2Final.c
*@author G.Satya Vamsi
*@function A class that deletes the last element
*@dated 30-Jul-2019
*/
void delfront(){
    struct node* temp;
	if(front1==NULL)
		printf("Queue is empty");
	else
		front1=front1->link;
    /*If size is half the capacity,then capacity becomes half*/
	if(cap==2*len){
        rear1->link=NULL;
        rear2=rear1;
        temp=front2;
        if(front2!=front1){
            while(temp->link!=front1)
            temp=temp->link;
            temp->link=NULL;
            front2=front1;
        }
    }
}

/**file L1Q2Final.c
*@author G.Satya Vamsi
*@function main class that asks user different instructions
*@dated 30-Jul-2019
*/
int main(){
	int order,v1,v2,v3=4;
	while(v3>0){
		printf("\nWhat do you want?\n1.Insert at end\n2.Insert at front\n3.Delete at end\n4.Delete at front\n5.Print capacity\n6.Print length\n7.Print dequeue\n8.Exit\n");
		scanf("%d",&v1);        /*Based on input the program performs various operations*/
		if(v1==1){
			printf("What do you want to insert?\n");
			scanf("%d",&v2);
			insertrear(v2);
		}
		if(v1==2){
			printf("What do you want to insert?\n");
			scanf("%d",&v2);
			insertfront(v2);
		}
		if(v1==3){
			delend();
		}
		if(v1==4){
			delfront();
		}
		if(v1==5){
			printcapacity();
		}
		if(v1==6){
			printsize();
		}
		if(v1==7){
            print();
		}
		if(v1==8){
			break;
		}
	}
}
