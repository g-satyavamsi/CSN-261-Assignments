/**
 * @file L5Q1.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Addition and Multiplication of two polynomials
 */


#include <iostream>
#include <vector>
using namespace std;

int main(){
    int ind1,ind2,ind3,i,j,l;
    int sum[100],prod[200];
    vector<int> v1,v2,v3,v4;

    cin>>ind1;
    ind1--;
/**
 * @file L5Q1.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Takes inputs and stores in vectors
 */
    for(i=ind1;i>=0;i--){
        cin>>l;
        v1.push_back(l);
    }
        
    
    cin>>ind2;
    ind2--;
    for(i=ind2;i>=0;i--){
        cin>>l;
        v2.push_back(l); 
    }   

    int max=ind1;
    if(ind1<ind2)
        max=ind2;

    for(i=max;i>=0;i--){
        v3.push_back(0);
    }
    for(i=0;i<=max;i++){
        v3[i]=v1[ind1-i]+v2[ind2-i];
        ind3=i;
    }

    for(i=0;i<=ind1;i++){
        for(j=0;j<=ind2;j++){
            v4.push_back(0);
        }
    }
    for(i=0;i<=ind1;i++){
        for(j=0;j<=ind2;j++){
            v4[ind1-i+ind2-j]=(v1[ind1-i]*v2[ind2-j])+v4[ind1-i+ind2-j];
        }
    }

    int k;
    cout<<"1.Sum\n2.Product"<<endl;
    cin>>k;
    
/**
 * @file L5Q1.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Prints added,multiplied polynomials
 */
    if(k==1){
        cout<<"Sum:"<<endl;
        for(i=max;i>=0;i--){
            cout<<v3[i]<<" "<<i<<endl;
        }
    }
    
    if(k==2){
        cout<<endl<<"Product:"<<endl;
        for(i=0;i<=ind1+ind2;i++){
            cout<<v4[i]<<" "<<ind1+ind2-i<<endl;
        }
    }
    
}