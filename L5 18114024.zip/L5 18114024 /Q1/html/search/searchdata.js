var indexSectionsWithContent =
{
  0: "l",
  1: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "files"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files"
};

