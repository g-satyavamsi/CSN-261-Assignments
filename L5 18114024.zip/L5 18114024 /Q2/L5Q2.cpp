/**
 * @file L5Q2.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Find MST using Kruskal's algorithm(Union Find)
 */

#include <iostream>
#include <string>
#include <fstream>
using namespace std; 

/**
 * @file L5Q2.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief An edge class
 */
class Edge 
{ 
	public: 
	int src, dest, weight; 
}; 

/**
 * @file L5Q2.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief A graph class
 */
class Graph 
{ 
	public: 
	int V, E; 
 
	Edge* edge; 
}; 

/**
 * @file L5Q2.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Create graph with given vertices and edges
 */
Graph* createGraph(int V, int E) 
{ 
	Graph* graph = new Graph; 
	graph->V = V; 
	graph->E = E; 

	graph->edge = new Edge[E]; 

	return graph; 
} 

/**
 * @file L5Q2.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief A class for subset of union find
 */
class subset 
{ 
	public: 
	int parent; 
	int rank; 
}; 
 
 /**
 * @file L5Q2.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief To find a given element
 * @param Integer
 */
int find(subset subsets[], int i) 
{ 
	if (subsets[i].parent != i) 
		subsets[i].parent = find(subsets, subsets[i].parent); 

	return subsets[i].parent; 
} 

/**
 * @file L5Q2.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Union of two sets
 */
void Union(subset subsets[], int x, int y) 
{ 
	int xroot = find(subsets, x); 
	int yroot = find(subsets, y); 

	if (subsets[xroot].rank < subsets[yroot].rank) 
		subsets[xroot].parent = yroot; 
	else if (subsets[xroot].rank > subsets[yroot].rank) 
		subsets[yroot].parent = xroot; 

	else
	{ 
		subsets[yroot].parent = xroot; 
		subsets[xroot].rank++; 
	} 
} 

/**
 * @file L5Q2.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Compare two edges according to weights
 */
int myComp(const void* a, const void* b) 
{ 
	Edge* a1 = (Edge*)a; 
	Edge* b1 = (Edge*)b; 
	return a1->weight > b1->weight; 
} 

ofstream outdata;

/**
 * @file L5Q2.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Kruskal's algorithm
 */
void KruskalMST(Graph* graph) 
{ 
	int V = graph->V; 
	Edge result[V]; 
	int e = 0; 
	int i = 0; 

	qsort(graph->edge, graph->E, sizeof(graph->edge[0]), myComp); 

	subset *subsets = new subset[( V * sizeof(subset) )]; 

	for (int v = 0; v < V; ++v) 
	{ 
		subsets[v].parent = v; 
		subsets[v].rank = 0; 
	} 

	while (e < V - 1 && i < graph->E) 
	{ 
		Edge next_edge = graph->edge[i++]; 

		int x = find(subsets, next_edge.src); 
		int y = find(subsets, next_edge.dest); 

		if (x != y) 
		{ 
			result[e++] = next_edge; 
			Union(subsets, x, y); 
		} 
	} 
 
	cout<<"Following are the edges in the constructed MST\n"; 
	for (i = 0; i < e; ++i) {
		cout<<char(result[i].src+64)<<"  "<<char(result[i].dest+64)<<"  "<<result[i].weight<<endl; 
        outdata<<" "<<char(result[i].src+64)<<"--"<<char(result[i].dest+64)<<"[label=\""<<result[i].weight<<"\"];"<<endl;
    }
    return; 
}

/**
 * @file L5Q2.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Main method
 */
int main() 
{   
    outdata.open("/home/satya/examp.dot");

    if( !outdata ) {
        cerr << "Error: file could not be opened" << endl;
        exit(1);
    }
    outdata<<"graph{"<<endl;

    string a,b,c;
	int i=0,j=0,edge=0,vert=0,count=0,arr[100];
    
    for(j=0;j<100;j++)
        arr[j]=0;

    ifstream ip("/home/satya/L5.csv");
    while(ip.good()){
        getline(ip,a,',');
        getline(ip,b,',');
        getline(ip,c,'\n');

        edge++;

		for(j=0;j<vert;j++){
            if(a[0]==arr[j])
                break;
        }
        if(j==vert){
            arr[j]=a[0];
            vert=vert+1;
        }

        for(j=0;j<vert;j++){
            if(b[0]==arr[j])
                break;
        }
        if(j==vert){
            arr[j]=b[0];
            vert++;
        }
    }

    int V = vert;  
	int E = edge;
    Graph* graph = createGraph(V, E);

    ifstream ip2("/home/satya/L5.csv");
    
    while(ip2.good()){
        getline(ip2,a,',');
        getline(ip2,b,',');
        getline(ip2,c,'\n');

		graph->edge[i].src = a[0]-64; 
		graph->edge[i].dest = b[0]-64; 
		graph->edge[i].weight = c[0]-48;
		i++;
    }
    
	KruskalMST(graph); 

    outdata<<"}";

    outdata.close();

	return 0; 
} 
