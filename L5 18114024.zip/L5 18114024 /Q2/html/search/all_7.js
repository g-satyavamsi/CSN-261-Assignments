var searchData=
[
  ['main',['main',['../_l5_q2_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'L5Q2.cpp']]],
  ['mycomp',['myComp',['../_l5_q2_8cpp.html#a27170c055caa9ddeaba871b386c22ae2',1,'L5Q2.cpp']]]
];
