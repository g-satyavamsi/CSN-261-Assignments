var searchData=
[
  ['parent',['parent',['../classsubset.html#ad8f7d99dc56f8ce3f0c3aaf4a633373a',1,'subset']]]
];
