from ete3 import Tree
l=[
("C","B","2"),
("A","C","4"),
("C","D","3"),
("F","E","3"),
("C","F","2"),
]
t = Tree.from_parent_child_table(l)
s=t.write()
tree=Tree(s)
print t.get_ascii(attributes=["name","label", "complex"])
