/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Prim's Algorithm with Fibonaci Heap
 */
#include <bits/stdc++.h> 
using namespace std; 
ofstream outdata;

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief To represent a node
 */
struct AdjListNode { 
	int dest; 
	int weight; 
	struct AdjListNode* next; 
}; 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Represent list
 */
struct AdjList { 
	struct AdjListNode* head;
}; 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Represent a graph
 */
struct Graph { 
	int V; 
	struct AdjList* array; 
}; 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Create a list
 */
struct AdjListNode* newAdjListNode(int dest, int weight) 
{ 
	struct AdjListNode* newNode = (struct AdjListNode*)malloc(sizeof(struct AdjListNode)); 
	newNode->dest = dest; 
	newNode->weight = weight; 
	newNode->next = NULL; 
	return newNode; 
} 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Create graph
 */
struct Graph* createGraph(int V) 
{ 
	struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph)); 
	graph->V = V; 

	graph->array = (struct AdjList*)malloc(V * sizeof(struct AdjList)); 

	for (int i = 0; i < V; ++i) 
		graph->array[i].head = NULL; 

	return graph; 
} 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Add edge to a graph
 */
void addEdge(struct Graph* graph, int src, int dest, int weight) 
{ 
	struct AdjListNode* newNode = newAdjListNode(dest, weight); 
	newNode->next = graph->array[src].head; 
	graph->array[src].head = newNode; 

	newNode = newAdjListNode(src, weight); 
	newNode->next = graph->array[dest].head; 
	graph->array[dest].head = newNode; 
} 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Create a node in Fibonacci heap
 */
struct FibHeapNode { 
	int v; 
	int key; 
}; 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Represent Fibonacci heap
 */
struct FibHeap { 
	int size;
	int capacity;
	int* pos; 
	struct FibHeapNode** array; 
}; 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Create a new Fibheap node
 */
struct FibHeapNode* newFibHeapNode(int v, int key) 
{ 
	struct FibHeapNode* fibHeapNode = (struct FibHeapNode*)malloc(sizeof(struct FibHeapNode)); 
	fibHeapNode->v = v; 
	fibHeapNode->key = key; 
	return fibHeapNode; 
} 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Create FibHeap
 */
struct FibHeap* createFibHeap(int capacity) 
{ 
	struct FibHeap* fibHeap = (struct FibHeap*)malloc(sizeof(struct FibHeap)); 
	fibHeap->pos = (int*)malloc(capacity * sizeof(int)); 
	fibHeap->size = 0; 
	fibHeap->capacity = capacity; 
	fibHeap->array = (struct FibHeapNode**)malloc(capacity * sizeof(struct FibHeapNode*)); 
	return fibHeap; 
} 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Swap nodes of FibHeap
 */
void swapFibHeapNode(struct FibHeapNode** a, struct FibHeapNode** b) 
{ 
	struct FibHeapNode* t = *a; 
	*a = *b; 
	*b = t; 
} 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Update position of node
 */
void fibHeapify(struct FibHeap* fibHeap, int idx) 
{ 
	int smallest, left, right; 
	smallest = idx; 
	left = 2 * idx + 1; 
	right = 2 * idx + 2; 

	if (left < fibHeap->size && fibHeap->array[left]->key < fibHeap->array[smallest]->key) 
		smallest = left; 

	if (right < fibHeap->size && fibHeap->array[right]->key < fibHeap->array[smallest]->key) 
		smallest = right; 

	if (smallest != idx) { 
		FibHeapNode* smallestNode = fibHeap->array[smallest]; 
		FibHeapNode* idxNode = fibHeap->array[idx]; 

		fibHeap->pos[smallestNode->v] = idx; 
		fibHeap->pos[idxNode->v] = smallest; 

		swapFibHeapNode(&fibHeap->array[smallest], &fibHeap->array[idx]); 

		fibHeapify(fibHeap, smallest); 
	} 
} 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Check if heap is empty
 */
int isEmpty(struct FibHeap* fibHeap) 
{ 
	return fibHeap->size == 0; 
} 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Extract node
 */
struct FibHeapNode* extractFib(struct FibHeap* fibHeap) 
{ 
	if (isEmpty(fibHeap)) 
		return NULL; 

	struct FibHeapNode* root = fibHeap->array[0]; 

	struct FibHeapNode* lastNode = fibHeap->array[fibHeap->size - 1]; 
	fibHeap->array[0] = lastNode; 

	fibHeap->pos[root->v] = fibHeap->size - 1; 
	fibHeap->pos[lastNode->v] = 0; 

	--fibHeap->size; 
	fibHeapify(fibHeap, 0); 

	return root; 
} 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Decrease key of a node
 */
void decreaseKey(struct FibHeap* fibHeap, int v, int key) 
{ 
	int i = fibHeap->pos[v]; 

	fibHeap->array[i]->key = key; 

	while (i && fibHeap->array[i]->key < fibHeap->array[(i - 1) / 2]->key) { 
		fibHeap->pos[fibHeap->array[i]->v] = (i - 1) / 2; 
		fibHeap->pos[fibHeap->array[(i - 1) / 2]->v] = i; 
		swapFibHeapNode(&fibHeap->array[i], &fibHeap->array[(i - 1) / 2]); 

		i = (i - 1) / 2; 
	} 
} 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Check if given node is in heap
 */
bool isInFibHeap(struct FibHeap* fibHeap, int v) 
{ 
	if (fibHeap->pos[v] < fibHeap->size) 
		return true; 
	return false; 
} 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Print MST
 */
void printArr(int arr[],int b[], int n) 
{ 
	for (int i = 1; i < n; ++i){
		printf("%c %c %d\n", (char)(arr[i]+65),(char)(i+65),b[i]); 
        outdata<<"(\""<<(char)(arr[i]+65)<<"\",\""<<(char)(i+65)<<"\",\""<<b[i]<<"\"),"<<endl;
    }

} 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Construct MST
 */
void PrimMST(struct Graph* graph) 
{ 
	int V = graph->V; 
	int parent[V]; 
	int key[V]; 

	struct FibHeap* fibHeap = createFibHeap(V); 

	for (int v = 1; v < V; ++v) { 
		parent[v] = -1; 
		key[v] = INT_MAX; 
		fibHeap->array[v] = newFibHeapNode(v, key[v]); 
		fibHeap->pos[v] = v; 
	} 

	key[0] = 0; 
	fibHeap->array[0] = newFibHeapNode(0, key[0]); 
	fibHeap->pos[0] = 0; 

	fibHeap->size = V; 

	while (!isEmpty(fibHeap)) { 

		struct FibHeapNode* fibHeapNode = extractFib(fibHeap); 
		int u = fibHeapNode->v; 

		struct AdjListNode* pCrawl = graph->array[u].head; 
		while (pCrawl != NULL) { 
			int v = pCrawl->dest; 

			if (isInFibHeap(fibHeap, v) && pCrawl->weight < key[v]) { 
				key[v] = pCrawl->weight; 
				parent[v] = u; 
				decreaseKey(fibHeap, v, key[v]); 
			} 
			pCrawl = pCrawl->next; 
		} 
	} 

	printArr(parent,key, V); 
} 

/**
 * @file L5Q3.cpp 
 * @author G.Satya Vamsi
 * @date Oct 01,2019
 * @brief Main function
 */
int main() 
{
    outdata.open("/home/satya/Desktop/new.py");

    if( !outdata ) {
        cerr << "Error: file could not be opened" << endl;
        exit(1);
    }
    outdata<<"from ete3 import Tree\nl=["<<endl;

    string a,b,c;
	int i=0,j=0,edge=0,vert=0,count=0,arr[100];
    
    for(j=0;j<100;j++)
        arr[j]=0;

    ifstream ip("/home/satya/L5.csv");
    while(ip.good()){
        getline(ip,a,',');
        getline(ip,b,',');
        getline(ip,c,'\n');

		for(j=0;j<vert;j++)
            if(a[0]==arr[j])
                break;

        if(j==vert){
            arr[j]=a[0];
            vert=vert+1;
        }

        for(j=0;j<vert;j++)
            if(b[0]==arr[j])
                break;
        
        if(j==vert){
            arr[j]=b[0];
            vert++;
        }
    }
	int V = vert; 

	struct Graph* graph = createGraph(V); 

	ifstream ip2("/home/satya/L5.csv");
    
    while(ip2.good()){
        getline(ip2,a,',');
        getline(ip2,b,',');
        getline(ip2,c,'\n');

		addEdge(graph,a[0]-65,b[0]-65,c[0]-48);
    }

	PrimMST(graph); 
    outdata<<"]\nt = Tree.from_parent_child_table(l)\ns=t.write()\ntree=Tree(s)\nprint t.get_ascii(attributes=[\"name\",\"label\", \"complex\"])"<<endl;
    outdata.close();

	return 0; 
} 
