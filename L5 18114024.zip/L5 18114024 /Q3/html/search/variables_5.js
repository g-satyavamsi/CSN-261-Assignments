var searchData=
[
  ['next',['next',['../struct_adj_list_node.html#ad07931f1bcb5ab15b9baf380a118242c',1,'AdjListNode']]]
];
