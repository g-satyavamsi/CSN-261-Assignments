var searchData=
[
  ['head',['head',['../struct_adj_list.html#a4f2ab2ed8e90ceae8bf50373e4e97e87',1,'AdjList']]]
];
