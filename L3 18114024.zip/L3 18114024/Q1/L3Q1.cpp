/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Prepare BST,AVL,Red-Black Trees
*/
#include <iostream>

using namespace std;

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief A class Node is created
*/
class Node{
public:
    int data,height,color,level;
    Node *left,*right,*parent;
};

Node* rootbst=NULL;
Node* rootavl=NULL;
Node* rootrb=NULL;

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief A node is created with given input
*/
Node *createnode(int x){
    Node* newnode=new Node();
    newnode->data=x;
    newnode->left=newnode->right=NULL;
    newnode->height=1;
    return newnode;
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Finds maximum number among two
*@param Integer
*/
int max(int a,int b){
    if(a>b)
        return a;
    return b;
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Calculates height of a node
*@param Height of a node
*/
int height(Node *temp){
    if(temp==NULL)
        return 0;
    return temp->height;
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief calculates balance factor of a node
*@param Balance factor
*/
int balance(Node *temp){
    if(temp==NULL)
        return 0;
    return (height(temp->left)-height(temp->right));
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Updates height of a node
*/
void setheight(Node *temp){
    temp->height=max(height(temp->left),height(temp->right))+1;
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Updates level of a node
*/
void getlevel(Node *node){
    if(node->left==NULL && node->right==NULL){
        node->level=0;
    }
    else if(node->left==NULL && node->right!=NULL){
        getlevel(node->right);
        node->level=(node->right->level)+1;
    }
    else if(node->right==NULL && node->left!=NULL){
        getlevel(node->left);
        node->level=node->left->level+1;}
    else if(node->left!=NULL && node->right!=NULL){
        getlevel(node->left);
        getlevel(node->right);
        node->level=max(node->left->level,node->right->level)+1;}
}
/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Gives level of a node
*@param Level of a node
*/
int getlevel2(Node *node){
    if(node==NULL)
        return 0;
    getlevel(node);
    return node->level;
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Right rotation in an AVL tree
*/
Node *rightrotate_avl(Node *temp){
    Node *templ=temp->left;
    Node *templr=templ->right;

    templ->right=temp;
    temp->left=templr;

    setheight(temp);
    setheight(templ);

    return templ;
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Left rotation in an AVL tree
*/
Node *leftrotate_avl(Node *temp){
    Node *tempr=temp->right;
    Node *temprl=tempr->left;

    tempr->left=temp;
    temp->right=temprl;

    setheight(temp);
    setheight(tempr);

    return tempr;
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Searches a node with given data
*@param A node
*/
Node* search(Node* node,int x){
    Node* temp=node;
    if(node==NULL || rootbst->data==x)
        return rootbst;
    if(temp->data<x)
        return search(temp->right,x);
    if(temp->data>x)
        return search(temp->left,x);
    else
    	return rootbst;
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Right rotation in a Red-Black tree
*/
void rightrotate_rb(Node *&rootrb,Node *&temp){
    Node *temp_left=temp->left;
    temp->left=temp_left->right;

    if(temp->left!=NULL)
        temp->left->parent=temp;
    temp_left->parent=temp->parent;

    if(temp->parent==NULL)
        rootrb=temp_left;
    else if(temp==temp->parent->left)
        temp->parent->left=temp_left;
    else
        temp->parent->right=temp_left;

    temp_left->right=temp;
    temp->parent=temp_left;
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Left rotation in a Red-Black tree
*/
void leftrotate_rb(Node *&rootrb,Node *&temp){
    Node *temp_right=temp->right;
    temp->right=temp_right->left;

    if (temp->right!=NULL)
        temp->right->parent=temp;
    temp_right->parent=temp->parent;

    if (temp->parent==NULL)
        rootrb = temp_right;
    else if (temp==temp->parent->left)
        temp->parent->left=temp_right;
    else
        temp->parent->right=temp_right;

    temp_right->left=temp;
    temp->parent=temp_right;
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Updates AVL tree(rotations)
*/
void fixit(Node *&rootrb,Node *&temp){
    Node *parent_temp=NULL;
    Node *grandparent_temp=NULL;

    while((temp!=rootrb) && (temp->color!=0) && (temp->parent->color==1)){
        parent_temp=temp->parent;
        grandparent_temp=temp->parent->parent;

        if(parent_temp==grandparent_temp->left){
            Node *uncle_temp=grandparent_temp->right;

            if(uncle_temp!=NULL && uncle_temp->color==1){
                grandparent_temp->color=1;
                parent_temp->color=0;
                uncle_temp->color=0;
                temp=grandparent_temp;
            }

            else{
                if(temp==parent_temp->right){
                    leftrotate_rb(rootrb,parent_temp);
                    temp=parent_temp;
                    parent_temp=temp->parent;
                }

                rightrotate_rb(rootrb,grandparent_temp);
                swap(parent_temp->color,grandparent_temp->color);
                temp=parent_temp;
            }
        }

        else{
            Node *uncle_temp=grandparent_temp->left;

            if(uncle_temp!=NULL && uncle_temp->color==1){
                grandparent_temp->color=1;
                parent_temp->color=0;
                uncle_temp->color=0;
                temp=grandparent_temp;
            }

            else{
                if(temp==parent_temp->left){
                    rightrotate_rb(rootrb,parent_temp);
                    temp=parent_temp;
                    parent_temp=temp->parent;
                }

                leftrotate_rb(rootrb,grandparent_temp);
                swap(parent_temp->color,grandparent_temp->color);
                temp=parent_temp;
            }
        }
    }
    rootrb->color=0;
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Insert Nodes in BST tree
*/
Node *insertnode_bst(Node* node,int x){
    if(node==NULL)
        return createnode(x);

    if(node->data<x)
        node->right=insertnode_bst(node->right,x);

    if(node->data>x)
        node->left=insertnode_bst(node->left,x);

    return node;
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Insert Nodes in AVL tree
*/
Node *insertnode_avl(Node *node,int x){
    if(node==NULL)
        return createnode(x);
    if(node->data>x)
        node->left=insertnode_avl(node->left,x);
    if(node->data<x)
        node->right=insertnode_avl(node->right,x);

    setheight(node);

    int b=0;
    b=balance(node);

    if(b>1 && x<node->left->data)
        return rightrotate_avl(node);
    if(b<-1 && x>node->right->data)
        return leftrotate_avl(node);
    if(b>1 && x>node->left->data){
        node->left=leftrotate_avl(node->left);
        return rightrotate_avl(node);
    }
    if(b<-1 && x<node->right->data){
        node->right=rightrotate_avl(node->right);
        return leftrotate_avl(node);
    }

    return node;
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Insert Nodes in Red-Black tree
*/
Node *insert_rb(Node *node,Node *temp){
    if(node==NULL)
        return temp;

    if(node->data<temp->data){
        node->right=insert_rb(node->right,temp);
        node->right->parent=node;
    }

    if(node->data>temp->data){
        node->left=insert_rb(node->left,temp);
        node->left->parent=node;
    }

    return node;
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Insert Nodes in Red-Black tree
*/
void insertnode_rb(int x){
    Node *temp=new Node();
    temp->data=x;
    temp->color=1;
    temp->left=temp->right=temp->parent=NULL;
    rootrb=insert_rb(rootrb,temp);
    fixit(rootrb,temp);
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Prints inorder of a tree
*/
void inorder(Node *root) {
    if (root != NULL) {
        inorder(root->left);
        cout<<root->data<<" ";
        inorder(root->right);
    }
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Gives values to AVL tree
*/
void giveit(Node *node){
    if(node!=NULL){
        giveit(node->left);
        rootavl=insertnode_avl(rootavl,node->data);
        giveit(node->right);
    }
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Prints BST tree
*/
void print_bst(Node* node,int z){
    int i=0;
    if(node==NULL)
        return;
    while(i<z){
        cout<<"\t";
        i++;
    }
    cout<<node->data<<"["<<getlevel2(node)<<"]"<<endl;
    print_bst(node->left,z+1);
    print_bst(node->right,z+1);
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Prints AVL tree
*/
void print_avl(Node *node,int z){
    int i=0;
    if(node==NULL)
        return;
    while(i<z){
        cout<<"\t";
        i++;
    }
    cout<<node->data<<"["<<balance(node)<<"]"<<endl;
    print_avl(node->left,z+1);
    print_avl(node->right,z+1);
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Prints Red-Black tree
*/
void print_rb(Node *node,int z){
    int i=0;
    if(node==NULL)
        return;
    while(i<z){
        cout<<"\t";
        i++;
    }
    if(node->color==0)
        cout<<node->data<<"[BLACK]"<<endl;
    if(node->color==1)
        cout<<node->data<<"[RED]"<<endl;

    print_rb(node->left,z+1);
    print_rb(node->right,z+1);
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Prints array
*/
void printArray(int ints[], int len,int len2)  {
    int i;
    for (i = len; i < len2; i++)  {
        if(i!=len2-1)
            cout << ints[i] << "->";
        else
        cout << ints[i];
    }
    cout<<endl;
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Prints sub paths
*/
void printPathsRecur(Node* node,int path[],int pathLen){
    if (node == NULL)
        return;

    path[pathLen] = node->data;
    pathLen++;

    if (node->left == NULL && node->right == NULL)  {
        for(int i=0;i<=pathLen;i++)
        printArray(path, i,pathLen);
    }
    else{
        printPathsRecur(node->left, path, pathLen);
        printPathsRecur(node->right, path, pathLen);
    }
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Prints paths
*/
void paths(Node* node){
    int path[1000];
    printPathsRecur(node, path, 0);
}

/**@file L3Q1.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief 'main' function
*/
int main(){
    int inp,tt=1;
    while(tt>0){
        cout<<"Select an operation..."<<endl;
        cout<<"1. To insert a node in the BST and in the Red-Black tree\n2. To create AVL tree from the BST\n3. To print the inorder traversal of the BST/AVL/Red-Black tree\n4. To display all the paths in the BST/AVL tree/Red-Black tree\n5. To print the BST/AVL tree/Red-Black Tree using level-wise indentation\n6. Exit"<<endl;
        cin>>inp;
        if(inp==1){
            cout<<endl<<"Please enter the number to be inserted"<<endl;
            cin>>inp;
            rootbst = insertnode_bst(rootbst, inp);
            insertnode_rb(inp);
            cout<<"Node is inserted"<<endl<<endl;
        }
        else if(inp==2){
            giveit(rootbst);
            cout<<"AVL tree is prepared"<<endl<<endl;
        }
        else if(inp==3){
            cout<<endl;
            if(rootbst==NULL)
                cout<<"No node present in BST tree!!"<<endl;
            else{
                cout<<"Inorder traversal of BST tree:"<<endl;
                inorder(rootbst);
            }
            cout<<endl;
            if(rootavl==NULL)
                cout<<"No node present in AVL tree!!"<<endl;
            else{
                cout<<"Inorder traversal of AVL tree:"<<endl;
                inorder(rootavl);
            }

            cout<<endl;
            if(rootrb==NULL)
                cout<<"No node present in Red-Black tree!!"<<endl;
            else{
                cout<<"Inorder traversal of Red-Black tree:"<<endl;
                inorder(rootrb);
            }

            cout<<endl<<endl;
        }
        else if(inp==4){
            cout<<endl;
            if(rootbst==NULL)
                cout<<"No node present in BST tree!!"<<endl;
            else{
                cout<<"All the paths in BST tree:"<<endl;
                paths(rootbst);
            }
            if(rootavl==NULL)
                cout<<"No node present in AVL tree!!"<<endl;
            else{
                cout<<"All the paths in AVL tree:"<<endl;
                paths(rootavl);
            }
            if(rootrb==NULL)
                cout<<"No node present in Red-Black tree!!"<<endl;
            else{
                cout<<"All the paths in Red-Black tree:"<<endl;
                paths(rootrb);
            }
            cout<<endl;
        }
        else if(inp==5){
            cout<<endl;
            if(rootbst==NULL)
                cout<<"No node present in BST tree!!"<<endl;
            else{
                cout<<"Level wise indentation of BST tree:"<<endl;
                print_bst(rootbst,0);
            }

            if(rootavl==NULL)
                cout<<"No node present in AVL tree!!"<<endl;
            else{
                cout<<"Level wise indentation of AVL tree:"<<endl;
                print_avl(rootavl,0);
            }

            if(rootrb==NULL)
                cout<<"No node present in Red-Black tree!!"<<endl;
            else{
                cout<<"Level wise indentation of Red-Black tree:"<<endl;
                print_rb(rootrb,0);
            }

            cout<<endl;
        }
        else if(inp==6){
            break;
        }
    }
}
