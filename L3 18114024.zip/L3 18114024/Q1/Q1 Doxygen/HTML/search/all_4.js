var searchData=
[
  ['getlevel',['getlevel',['../_l3_q1_8cpp.html#acbdb3888761f1d7d4f99cf6e40ad6422',1,'L3Q1.cpp']]],
  ['getlevel2',['getlevel2',['../_l3_q1_8cpp.html#af454dc540f58c37e68edd9291e8ecbbd',1,'L3Q1.cpp']]],
  ['giveit',['giveit',['../_l3_q1_8cpp.html#a73d7760f98e03748c92aa096ffebe096',1,'L3Q1.cpp']]]
];
