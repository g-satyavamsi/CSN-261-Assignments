var searchData=
[
  ['search',['search',['../_l3_q1_8cpp.html#a6e8d359f4303b4703f605e087b708308',1,'L3Q1.cpp']]],
  ['setheight',['setheight',['../_l3_q1_8cpp.html#af7f21ec54299d6321d86ece064cb469f',1,'L3Q1.cpp']]]
];
