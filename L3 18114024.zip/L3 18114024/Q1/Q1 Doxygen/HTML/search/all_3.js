var searchData=
[
  ['fixit',['fixit',['../_l3_q1_8cpp.html#a34f379a4479ed895c9a9328ccaa20014',1,'L3Q1.cpp']]]
];
