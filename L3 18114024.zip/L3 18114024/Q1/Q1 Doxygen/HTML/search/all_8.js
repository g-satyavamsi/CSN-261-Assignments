var searchData=
[
  ['main',['main',['../_l3_q1_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'L3Q1.cpp']]],
  ['max',['max',['../_l3_q1_8cpp.html#af082905f7eac6d03e92015146bbc1925',1,'L3Q1.cpp']]]
];
