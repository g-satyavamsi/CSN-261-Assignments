var searchData=
[
  ['color',['color',['../class_node.html#a93c3541cf1732295e682d7eee29980de',1,'Node']]]
];
