/**@file L3Q2.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Finding triplets satisfying a given condition
*/

#include <iostream>
using namespace std;

int ind=1,t,i,j,k,count=0;

/**@file L3Q2.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Creating a node class
*/
class Node{
    public:
	int data;
	int index;
	Node* link;
};

Node *head=NULL;
Node *tempnode=NULL;

/**@file L3Q2.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Inserts a given integer into linked list
*@param Linked list gets updated
*/
void insert(int x){
	if(head==NULL){
		Node *newnode=new Node();
		newnode->data=x;
		newnode->index=ind;
		ind++;
		newnode->link=NULL;
		head=newnode;
		tempnode=newnode;
		return;
	}

	Node *newnode=new Node();
	newnode->data=x;
	newnode->index=ind;
	ind++;
	newnode->link=NULL;
	tempnode->link=newnode;
	tempnode=newnode;
}

/**@file L3Q2.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief Storing the calculated data in a 2D array
*/
int fillit(int x,int y,int **a){
	if(a[x][y]!=-1)
		return a[x][y];
	t=0;
	Node *temp=head;
	while(temp->index!=x)
		temp=temp->link;

	t=temp->data;
	while(temp->index<y){
		t=t^(temp->link->data);
		temp=temp->link;
	}

	a[x][y]=t;
	return a[x][y];
}

/**@file L3Q2.cpp
*@author G.Satya Vamsi
*@date 20/08/19
*@brief 'main' function
*@param
*/
int main(){
	int n,p=0,m;
	cout<<"Enter the total number of integers"<<endl;
	cin>>n;
	cout<<"Enter the integers continuously"<<endl;
	while(p<n){
		cin>>m;
		insert(m);
		p++;
	}

	int **arr=new int*[n+1];
	for(i=0;i<n+1;i++)
		arr[i]=new int[n+1];

	for(i=0;i<n+1;i++)
		for(j=0;j<n+1;j++)
			arr[i][j]=-1;

	///Three pointers move checking whether given condition is satisfied
	cout<<endl<<"Triplets:"<<endl;
    count=0;
	i=j=k=1;
	for(i=1;i<=n;i++)
		for(j=i+1;j<=n;j++)
			for(k=j;k<=n;k++)
				if(fillit(i,j-1,&arr[0])==fillit(j,k,&arr[0])){
					count++;
					cout<<"("<<i<<","<<j<<","<<k<<")"<<endl;
				}

	cout<<endl<<"Total number of triplets:"<<count<<endl;
}
