var searchData=
[
  ['j',['j',['../_l3_q2_8cpp.html#a37d972ae0b47b9099e30983131d31916',1,'L3Q2.cpp']]]
];
