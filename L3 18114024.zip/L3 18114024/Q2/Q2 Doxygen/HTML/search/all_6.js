var searchData=
[
  ['k',['k',['../_l3_q2_8cpp.html#ab66ed8e0098c0a86b458672a55a9cca9',1,'L3Q2.cpp']]]
];
