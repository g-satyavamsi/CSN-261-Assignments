var indexSectionsWithContent =
{
  0: "cdfhijklmnt",
  1: "n",
  2: "l",
  3: "fim",
  4: "cdhijklt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

