var searchData=
[
  ['head',['head',['../_l3_q2_8cpp.html#aa3e81b47ac0637ebb1ea7cc12812405a',1,'L3Q2.cpp']]]
];
