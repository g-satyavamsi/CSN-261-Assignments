var searchData=
[
  ['link',['link',['../class_node.html#a44bb6f65459bbec0064fad001706d242',1,'Node']]]
];
